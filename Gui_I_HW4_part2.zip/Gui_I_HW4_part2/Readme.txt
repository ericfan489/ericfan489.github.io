Eric Fan
GUI 1 HW 4
part 1 url: https://ericfan489.github.io/Gui_I_HW4/HW4_form.html
part 2 url: https://ericfan489.github.io/Gui_I_HW4_part2/HW4_form_2.html

For this assignment I used jquery for error handling and used the previous assignment. I used jqeury validation for error handling for the first part of the assignment.
This made is so error messages would be displayed to the screen dynamically if the user did not input correct inputs. For the second part of this assignment I used jqeury UI to implement 
sliders and tabs.