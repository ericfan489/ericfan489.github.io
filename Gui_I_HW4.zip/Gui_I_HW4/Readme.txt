Eric Fan
GUI 1 HW 3
url: https://ericfan489.github.io/GUI_I_HW3/HW3_form.html

For this assignment I made a dynamic multiplication table that uses the input from the user as the max and min for the columns and rows.
I put in some error checking for when the inputs are out of range and if the min is greater than the max.